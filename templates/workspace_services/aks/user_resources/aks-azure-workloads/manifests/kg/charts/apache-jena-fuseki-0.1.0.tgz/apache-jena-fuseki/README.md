# Apache Jena Fuseki Helm Chart

A simple Helm chart for deploying Apache Jena Fuseki knowledge graph server on Kubernetes.

## Features

- 🚀 Simple deployment with minimal configuration
- 📊 SPARQL query and update endpoints
- 🌐 Web UI for administration
- 💾 Persistent TDB2 storage for data
- � Automated data loading on startup
- 🔒 Secure authentication with externalized passwords
- 📈 Health checks and monitoring
- 🔧 Configurable resources and scaling
- 🏗️ Multi-container deployment with init containers

## Quick Start

### Install the Chart

```bash
# Basic installation
helm install fuseki ./AJF-Helm

# Production installation with external password
helm install fuseki ./AJF-Helm --set fuseki.admin.password=your-secure-password

# Or with custom release name
helm install my-fuseki ./AJF-Helm --set fuseki.admin.password=your-secure-password
```

### Access the Services

```bash
# Option 1: Direct external access via LoadBalancer
kubectl get svc fuseki-apache-jena-fuseki
# Use the EXTERNAL-IP shown in the output

# Option 2: Port forward for local development
kubectl port-forward svc/fuseki-apache-jena-fuseki 3030:3030
open http://localhost:3030

# Option 3: Internal cluster access via service FQDN
# Service FQDN: fuseki-apache-jena-fuseki.default.svc.cluster.local:3030
# (replace 'default' with your actual namespace)

# Test SPARQL endpoint (adjust URL based on access method)
curl -X POST \
  -H "Content-Type: application/sparql-query" \
  -d "SELECT * WHERE { ?s ?p ?o } LIMIT 10" \
  http://EXTERNAL-IP:3030/aircraft-maintenance/sparql
```

## Architecture

### Multi-Container Deployment

The chart deploys a multi-container pod with the following containers:

1. **fuseki**: Main Apache Jena Fuseki server with persistent TDB2 storage
2. **data-loader**: Sidecar container that automatically loads aircraft-maintenance ontology

### Data Flow

1. Fuseki starts with ConfigMap-based configuration pointing to persistent TDB2 storage
2. Data-loader detects empty database and loads aircraft-maintenance ontology (305 triples)
3. Data persists across pod restarts via PersistentVolumeClaim

### Storage

- **Type**: TDB2 (Apache Jena's native triple store)
- **Location**: `/fuseki/databases/aircraft-maintenance`
- **Persistence**: Kubernetes PersistentVolumeClaim
- **Access**: ReadWriteOnce (single node attachment)

### OWL Reasoning

The deployment includes two datasets:

1. **aircraft-maintenance**: Base dataset with raw data (read/write)
2. **aircraft-maintenance-inf**: Inference dataset with OWL reasoning (read-only)

The inference dataset uses Apache Jena's OWL Forward-chaining reasoner to automatically derive:
- **Class hierarchies**: Subclass relationships
- **Property hierarchies**: Property inheritance
- **Type inference**: Automatic classification
- **Property domains/ranges**: Constraint validation

**Example Usage:**
```sparql
# Query base data (no inference)
SELECT * WHERE { ?s ?p ?o } 
# → http://localhost:3030/aircraft-maintenance/sparql

# Query with OWL inference
SELECT * WHERE { ?s a :MaintenanceTask } 
# → http://localhost:3030/aircraft-maintenance-inf/sparql
```

## Configuration

### Basic Configuration

```yaml
# values.yaml
replicaCount: 1

image:
  repository: stain/jena-fuseki
  tag: "latest"

service:
  type: LoadBalancer
  port: 3030
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-external: "true"

resources:
  limits:
    cpu: 1000m
    memory: 2Gi
  requests:
    cpu: 500m
    memory: 1Gi
```

### Persistence

```yaml
persistence:
  enabled: true
  storageClass: "fast-ssd"
  size: 50Gi
```

### Automated Data Loading

The chart includes automated loading of the aircraft-maintenance ontology on startup:

```yaml
# Data loading is enabled by default
# The aircraft-maintenance dataset will be automatically loaded
# Data persists across pod restarts using TDB2 storage
```

### Security Configuration

```yaml
# Secure password configuration (recommended for production)
fuseki:
  admin:
    password: ""  # Pass via --set fuseki.admin.password=your-password

# Alternative: Use in values.yaml for development only
fuseki:
  admin:
    password: "development-password"
```

### Azure LoadBalancer Configuration

```yaml
# Azure-specific LoadBalancer configuration
service:
  type: LoadBalancer
  port: 3030
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-external: "true"
    # Optional: Specify static IP
    # service.beta.kubernetes.io/azure-load-balancer-ipv4: "20.1.2.3"
    # Optional: Specify resource group for static IP
    # service.beta.kubernetes.io/azure-load-balancer-resource-group: "my-rg"
```

## Available Endpoints

| Endpoint | Purpose | Method | Authentication | Features |
|----------|---------|--------|----------------|----------|
| `/` | Web UI | GET | None | Administration interface |
| `/aircraft-maintenance-query/sparql` | SPARQL Query (Public) | GET/POST | **None** | Read-only queries |
| `/aircraft-maintenance-query/data` | Graph Store (Public) | GET | **None** | Read-only data access |
| `/aircraft-maintenance/sparql` | SPARQL Query (Secured) | GET/POST | **Required** | Full query access |
| `/aircraft-maintenance/update` | SPARQL Update | POST | **Required** | Data modifications |
| `/aircraft-maintenance/data` | Graph Store (Secured) | GET/POST/PUT/DELETE | **Required** | Full data access |
| `/aircraft-maintenance/upload` | File Upload | POST | **Required** | Bulk data loading |
| `/aircraft-maintenance-inf/sparql` | SPARQL Query (With Inference) | GET/POST | **None** | **OWL reasoning enabled** |
| `/aircraft-maintenance-inf/data` | Graph Store (Inference) | GET | **None** | **Read-only inferred data** |
| `/$/ping` | Health Check | GET | None | Service status |

## Customization

### TDB2 Database Configuration

```yaml
# TDB2 is configured by default for persistence
# Database location: /fuseki/databases/aircraft-maintenance
# Supports concurrent read/write operations
```

### Custom Dataset

```yaml
fuseki:
  datasets:
    - name: "my-dataset"
      type: "tdb2"
```

### Environment Variables

```yaml
env:
  - name: JAVA_OPTIONS
    value: "-Xmx2g -Xms1g"
```

### Resource Limits

```yaml
resources:
  limits:
    cpu: 2000m
    memory: 4Gi
  requests:
    cpu: 1000m
    memory: 2Gi
```

## Scaling

```yaml
# Increase replicas for load balancing
replicaCount: 3

# Use LoadBalancer service type
service:
  type: LoadBalancer
```

## Security

```yaml
# Recommended: Pass password via command line
# helm install fuseki ./AJF-Helm --set fuseki.admin.password=your-secure-password

# Custom security context
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  runAsGroup: 1001
  fsGroup: 1001
```

## Troubleshooting

### Check Pod Status

```bash
kubectl get pods -l app.kubernetes.io/name=apache-jena-fuseki
```

### View Logs

```bash
kubectl logs -l app.kubernetes.io/name=apache-jena-fuseki
```

### Test Connectivity

```bash
kubectl exec -it deployment/fuseki-apache-jena-fuseki -- wget -qO- http://localhost:3030/$/ping
```

### Check Data Loading

```bash
# Verify aircraft-maintenance data is loaded
kubectl logs -l app.kubernetes.io/name=apache-jena-fuseki -c data-loader

# Query for data count (base dataset)
curl -X POST \
  -H "Content-Type: application/sparql-query" \
  -d "SELECT (COUNT(*) as ?count) WHERE { ?s ?p ?o }" \
  http://localhost:3030/aircraft-maintenance/sparql

# Test OWL inference capabilities
curl -X POST \
  -H "Content-Type: application/sparql-query" \
  -d "SELECT * WHERE { ?s a <http://www.w3.org/2002/07/owl#Class> } LIMIT 10" \
  http://localhost:3030/aircraft-maintenance-inf/sparql
```

## Development

### Validate Chart

```bash
helm lint ./AJF-Helm
helm template fuseki ./AJF-Helm
```

### Install in Development Mode

```bash
helm install fuseki ./AJF-Helm --set image.tag=dev --dry-run
```

### Test with Production Configuration

```bash
# Test deployment with external password
helm template fuseki ./AJF-Helm --set fuseki.admin.password=test-password

# Install with all production features
helm install fuseki ./AJF-Helm \
  --set fuseki.admin.password=secure-password \
  --set persistence.enabled=true \
  --set persistence.size=100Gi
```
