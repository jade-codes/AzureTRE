{{- define "vllm-cpu.name" -}}
vllm-cpu
{{- end -}}

{{- define "vllm-cpu.fullname" -}}
{{- printf "%s-%s" .Release.Name (include "vllm-cpu.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "vllm-cpu.labels" -}}
app.kubernetes.io/name: {{ include "vllm-cpu.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end -}}